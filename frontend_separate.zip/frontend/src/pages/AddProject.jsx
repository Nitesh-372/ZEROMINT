import React from 'react'
import Topbar from '../components/Topbar.jsx'

export default function AddProject(){
  return (
    <div className="space-y-5">
      <Topbar />
      <div className="card max-w-2xl p-6">
        <h2 className="text-lg font-semibold mb-4">Add New Project</h2>
        <div className="space-y-4">
          <div><label className="block text-sm font-semibold mb-1">Project Type</label><select className="input"><option>Select project type</option><option>Solar Energy</option><option>Wind Energy</option><option>Forestation</option><option>Biomass</option></select></div>
          <div><label className="block text-sm font-semibold mb-1">Project Name</label><input className="input" placeholder="e.g., Downtown Solar Installation"/></div>
          <div><label className="block text-sm font-semibold mb-1">Location</label><input className="input" placeholder="City, Country"/></div>
          <div><label className="block text-sm font-semibold mb-1">Project Description</label><textarea className="input" rows="4" placeholder="Describe your project in detail..."/></div>
          <div><label className="block text-sm font-semibold mb-1">Expected Carbon Credits</label><input className="input" placeholder="e.g., 150"/></div>
          <div><label className="block text-sm font-semibold mb-1">Upload Evidence</label><div className="input h-28 grid place-items-center border-dashed"><div className="text-slate-500 text-sm">Drag and drop files here, or click to browse</div></div></div>
          <button className="btn btn-primary w-full">Submit Project for Verification</button>
        </div>
      </div>
    </div>
  )
}
